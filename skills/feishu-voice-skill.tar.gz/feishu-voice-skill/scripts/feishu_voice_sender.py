#!/usr/bin/env python3
"""
飞书语音发送 Python 模块
完整流程: TTS -> 转换 -> 上传 -> 发送
"""

import os
import json
import subprocess
import requests

# 读取 OpenClaw 配置
OPENCLAW_CONFIG = os.path.expanduser("~/.openclaw/openclaw.json")

def load_credentials():
    """从 OpenClaw 配置读取飞书凭证"""
    try:
        with open(OPENCLAW_CONFIG) as f:
            config = json.load(f)
        feishu = config['channels']['feishu']
        return feishu['appId'], feishu['appSecret']
    except Exception as e:
        print(f"❌ 读取配置失败: {e}")
        return None, None

def generate_voice(text: str, output_path: str) -> bool:
    """使用 edge-tts 生成语音"""
    try:
        cmd = [
            "edge-tts",
            "--voice", "zh-CN-XiaoxiaoNeural",
            "--text", text,
            "--write-media", output_path
        ]
        subprocess.run(cmd, check=True, capture_output=True)
        return True
    except Exception as e:
        print(f"❌ TTS 生成失败: {e}")
        return False

def convert_to_opus(mp3_path: str, opus_path: str) -> bool:
    """使用 ffmpeg 转换为 Opus"""
    try:
        cmd = [
            "ffmpeg", "-i", mp3_path,
            "-c:a", "libopus", "-b:a", "16k",
            opus_path, "-y"
        ]
        subprocess.run(cmd, check=True, capture_output=True)
        return True
    except Exception as e:
        print(f"❌ 格式转换失败: {e}")
        return False

def get_token(app_id: str, app_secret: str) -> str:
    """获取飞书 tenant_access_token"""
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    resp = requests.post(url, json={"app_id": app_id, "app_secret": app_secret})
    return resp.json().get("tenant_access_token")

def upload_voice(token: str, opus_path: str) -> str:
    """上传语音文件，返回 file_key"""
    url = "https://open.feishu.cn/open-apis/im/v1/files"
    headers = {"Authorization": f"Bearer {token}"}
    
    # 获取音频时长
    import subprocess
    result = subprocess.run(
        ["ffprobe", "-i", opus_path, "-show_entries", "format=duration", 
         "-v", "quiet", "-of", "csv=p=0"],
        capture_output=True, text=True
    )
    duration_ms = int(float(result.stdout.strip()) * 1000)
    
    with open(opus_path, 'rb') as f:
        files = {
            'file_type': (None, 'opus'),
            'file_name': (None, 'voice.opus'),
            'file': ('voice.opus', f, 'audio/ogg'),
            'duration': (None, str(duration_ms))
        }
        resp = requests.post(url, headers=headers, files=files)
    
    return resp.json().get('data', {}).get('file_key')

def send_voice_message(token: str, receiver_id: str, file_key: str) -> bool:
    """发送语音消息"""
    url = "https://open.feishu.cn/open-apis/im/v1/messages"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    # 判断 ID 类型
    id_type = "open_id" if receiver_id.startswith("ou_") else "chat_id"
    
    params = {"receive_id_type": id_type}
    data = {
        "receive_id": receiver_id,
        "msg_type": "audio",
        "content": json.dumps({"file_key": file_key})
    }
    
    resp = requests.post(url, headers=headers, params=params, json=data)
    return resp.json().get("code") == 0

def send_voice(text: str, receiver_id: str) -> bool:
    """
    完整的语音发送流程
    
    Args:
        text: 要发送的文字
        receiver_id: 接收者ID (用户 open_id 或群 chat_id)
    
    Returns:
        是否成功
    """
    print(f"🎙️ 发送语音: {text[:50]}...")
    
    # 1. 读取凭证
    app_id, app_secret = load_credentials()
    if not app_id or not app_secret:
        return False
    
    # 2. 生成临时文件
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    mp3_path = os.path.join(tmp_dir, "voice.mp3")
    opus_path = os.path.join(tmp_dir, "voice.opus")
    
    try:
        # 3. TTS 生成
        print("Step 1/5: 生成语音...")
        if not generate_voice(text, mp3_path):
            return False
        print("   ✅ MP3 已生成")
        
        # 4. 格式转换
        print("Step 2/5: 转换格式...")
        if not convert_to_opus(mp3_path, opus_path):
            return False
        print("   ✅ Opus 已生成")
        
        # 5. 获取 Token
        print("Step 3/5: 获取授权...")
        token = get_token(app_id, app_secret)
        if not token:
            print("❌ 获取 Token 失败")
            return False
        print("   ✅ Token 已获取")
        
        # 6. 上传文件
        print("Step 4/5: 上传语音...")
        file_key = upload_voice(token, opus_path)
        if not file_key:
            print("❌ 上传失败")
            return False
        print("   ✅ 文件已上传")
        
        # 7. 发送消息
        print("Step 5/5: 发送消息...")
        if send_voice_message(token, receiver_id, file_key):
            print("✅ 发送成功！")
            return True
        else:
            print("❌ 发送失败")
            return False
    
    finally:
        # 清理临时文件
        import shutil
        shutil.rmtree(tmp_dir, ignore_errors=True)


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 3:
        print("用法: python3 feishu_voice_sender.py '文字' '接收者ID'")
        print("示例:")
        print("  python3 feishu_voice_sender.py '你好' 'ou_xxx'")
        sys.exit(1)
    
    text = sys.argv[1]
    receiver = sys.argv[2]
    
    success = send_voice(text, receiver)
    sys.exit(0 if success else 1)
