#!/bin/bash
# 飞书语音发送完整脚本
# 功能: TTS生成 + 格式转换 + 上传 + 发送

set -e

TEXT="$1"
RECEIVER_ID="${2:-}"

if [ -z "$TEXT" ] || [ -z "$RECEIVER_ID" ]; then
    echo "用法: $0 '要发送的文字' '接收者ID'"
    echo ""
    echo "示例:"
    echo "  $0 '你好' 'ou_5641c92cdb19076d92fdea001966b15c'"
    exit 1
fi

# 从 OpenClaw 配置读取凭证
OPENCLAW_CONFIG="${HOME}/.openclaw/openclaw.json"
if [ ! -f "$OPENCLAW_CONFIG" ]; then
    echo "❌ 错误: 找不到 OpenClaw 配置文件"
    exit 1
fi

APP_ID=$(python3 -c "import json; print(json.load(open('$OPENCLAW_CONFIG'))['channels']['feishu']['appId'])" 2>/dev/null)
APP_SECRET=$(python3 -c "import json; print(json.load(open('$OPENCLAW_CONFIG'))['channels']['feishu']['appSecret'])" 2>/dev/null)

if [ -z "$APP_ID" ] || [ -z "$APP_SECRET" ]; then
    echo "❌ 错误: 无法读取飞书凭证"
    exit 1
fi

echo "🎙️ 飞书语音发送: $TEXT"

# 临时文件
TMP_DIR=$(mktemp -d)
TMP_MP3="$TMP_DIR/voice.mp3"
TMP_OPUS="$TMP_DIR/voice.opus"

cleanup() { rm -rf "$TMP_DIR"; }
trap cleanup EXIT

# 1. TTS 生成
echo "Step 1/5: 生成语音..."
edge-tts --voice zh-CN-XiaoxiaoNeural --text "$TEXT" --write-media "$TMP_MP3" 2>/dev/null
echo "   ✅ MP3 已生成"

# 2. 格式转换
echo "Step 2/5: 转换格式..."
ffmpeg -i "$TMP_MP3" -c:a libopus -b:a 16k "$TMP_OPUS" -y 2>/dev/null
echo "   ✅ Opus 已生成"

# 3. 获取 Token
echo "Step 3/5: 获取授权..."
TOKEN=$(curl -s -X POST "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" \
    -H "Content-Type: application/json" \
    -d "{\"app_id\":\"$APP_ID\",\"app_secret\":\"$APP_SECRET\"}" | \
    grep -o '"tenant_access_token":"[^"]*"' | cut -d'"' -f4)
echo "   ✅ Token 已获取"

# 4. 上传文件
echo "Step 4/5: 上传语音..."
DURATION_MS=$(ffprobe -i "$TMP_OPUS" -show_entries format=duration -v quiet -of csv="p=0" 2>/dev/null | awk '{print int($1*1000)}')
FILE_KEY=$(curl -s -X POST "https://open.feishu.cn/open-apis/im/v1/files" \
    -H "Authorization: Bearer $TOKEN" \
    -F "file_type=opus" \
    -F "file_name=voice.opus" \
    -F "file=@$TMP_OPUS" \
    -F "duration=$DURATION_MS" | \
    grep -o '"file_key":"[^"]*"' | cut -d'"' -f4)
echo "   ✅ 文件已上传"

# 5. 发送消息
echo "Step 5/5: 发送消息..."
ID_TYPE=$([[ "$RECEIVER_ID" == ou_* ]] && echo "open_id" || echo "chat_id")
curl -s -X POST "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=$ID_TYPE" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"receive_id\":\"$RECEIVER_ID\",\"msg_type\":\"audio\",\"content\":\"{\\\"file_key\\\":\\\"$FILE_KEY\\\"}\"}" | grep -q '"code":0'

if [ $? -eq 0 ]; then
    echo "✅ 发送成功！"
else
    echo "❌ 发送失败"
    exit 1
fi
