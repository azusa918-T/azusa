# Feishu Voice 飞书语音发送技能

完整的飞书语音消息发送解决方案，包含文字转语音和发送全流程。

## 功能特性

- 🎙️ 文字转语音（TTS）- 使用 edge-tts
- 🔄 格式转换 - MP3 转 Opus
- 📤 飞书发送 - 完整 API 调用流程
- 🔧 自动读取配置 - 从 OpenClaw 配置读取凭证

## 使用方法

### 快速发送
```bash
cd scripts
./send_feishu_voice.sh "要发送的文字" "接收者ID"
```

### Python 调用
```python
from feishu_voice_sender import send_voice
send_voice("你好", "user_open_id")
```

## 文件结构
```
feishu-voice-skill/
├── SKILL.md              # 本文件
├── README.md             # 详细使用说明
└── scripts/
    ├── send_feishu_voice.sh   # 完整发送脚本
    └── feishu_voice_sender.py # Python 模块
```

## 依赖
- edge-tts
- ffmpeg
- curl
- Python 3.7+

## 配置
自动从 `~/.openclaw/openclaw.json` 读取飞书凭证，无需手动配置。
