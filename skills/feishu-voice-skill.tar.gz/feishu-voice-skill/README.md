# Feishu Voice 技能安装说明

## 安装步骤

1. 解压技能包
```bash
tar -xzf feishu-voice-skill.tar.gz -C ~/.openclaw/workspace/skills/
```

2. 安装依赖
```bash
pip3 install edge-tts
# ffmpeg 系统安装: apt-get install ffmpeg 或 brew install ffmpeg
```

3. 确保 OpenClaw 已配置飞书凭证
   - 配置文件: `~/.openclaw/openclaw.json`
   - 需要字段: `feishu.appId` 和 `feishu.appSecret`

## 完整使用示例

### Shell 脚本
```bash
cd ~/.openclaw/workspace/skills/feishu-voice-skill/scripts

# 发送语音到私聊
./send_feishu_voice.sh "你好，我是小明" "ou_xxx"

# 发送语音到群聊
./send_feishu_voice.sh "大家好" "oc_xxx"
```

### Python 调用
```python
import sys
sys.path.insert(0, 'scripts')
from feishu_voice_sender import send_voice

# 发送语音
result = send_voice("你好，我是小明", "ou_xxx")
if result:
    print("发送成功！")
else:
    print("发送失败")
```

## 工作流程

1. **TTS 生成** - edge-tts 生成 MP3
2. **格式转换** - ffmpeg 转为 Opus
3. **获取 Token** - 调用飞书授权接口
4. **上传文件** - 上传语音到飞书服务器
5. **发送消息** - 发送 audio 类型消息

## 故障排查

### 语音生成失败
- 检查 edge-tts 是否安装: `pip3 show edge-tts`

### 格式转换失败
- 检查 ffmpeg 是否安装: `ffmpeg -version`

### 发送失败
- 检查 OpenClaw 配置是否正确
- 检查接收者 ID 是否有效
- 检查 Bot 是否在目标群中（群聊）
