# DashScope ASR 语音转文字技能

阿里云 DashScope 语音文件转文字技能。

## ⚠️ 功能限制

**本技能仅支持：语音/音频文件 → 文字**

- ✅ 本地音频文件识别（MP3, WAV, M4A, OGG, OPUS 等）
- ❌ 不支持实时麦克风录音
- ❌ 不支持语音合成（TTS）

## 使用方法

### 命令行使用

```bash
# 进入脚本目录
cd scripts

# 识别音频文件
python3 dashscope_asr.py /path/to/audio.mp3

# 指定中文
python3 dashscope_asr.py /path/to/audio.mp3 -l zh

# 指定英文
python3 dashscope_asr.py /path/to/audio.mp3 -l en
```

### Python 代码调用

```python
from dashscope_asr import recognize_audio

# 识别音频文件为文字
result = recognize_audio("/path/to/audio.mp3", language="zh")
print(result)  # 输出识别出的文字
```

## 支持的音频格式

- MP3, WAV, M4A, OGG, OPUS, WEBM

## 文件结构

```
dashscope-asr-skill/
├── SKILL.md              # 本说明文档
└── scripts/
    └── dashscope_asr.py  # 语音转文字脚本
```

## API Key

脚本已内置阿里云 DashScope API Key。

## 依赖安装

```bash
pip3 install dashscope
```

## 示例

```bash
python3 dashscope_asr.py voice.ogg -l zh
```

输出：
```
==================================================
DashScope ASR 语音转文字
==================================================
正在识别: voice.ogg
文件大小: 7.44 KB
指定语言: zh

==================================================
识别结果:
==================================================
你帮我查询深圳的天气。
==================================================
```

---

**注意：本技能仅用于语音文件转文字，不支持其他功能。**
