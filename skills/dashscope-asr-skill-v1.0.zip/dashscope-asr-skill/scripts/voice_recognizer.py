#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Voice Message 语音消息识别
使用阿里云 DashScope 语音识别 API
支持飞书语音消息 (OGG/OPUS) 及常见音频格式
"""

import os
import sys
import dashscope

# API配置
API_KEY = "sk-dbb7ee50ac794454aa006b0d085a54bc"
dashscope.api_key = API_KEY

# 北京地域
dashscope.base_http_api_url = 'https://dashscope.aliyuncs.com/api/v1'
# 新加坡地域
# dashscope.base_http_api_url = 'https://dashscope-intl.aliyuncs.com/api/v1'
# 美国地域
# dashscope.base_http_api_url = 'https://dashscope-us.aliyuncs.com/api/v1'


def recognize_audio(file_path: str, language: str = None) -> str:
    """
    识别本地音频文件
    
    Args:
        file_path: 本地音频文件绝对路径
        language: 语言代码 (如 'zh', 'en')，可选
    
    Returns:
        识别出的文字
    """
    # 转换为绝对路径并添加 file:// 协议
    abs_path = os.path.abspath(file_path)
    if not os.path.exists(abs_path):
        print(f"错误: 文件不存在 {abs_path}")
        sys.exit(1)
    
    audio_file_path = f"file://{abs_path}"
    print(f"正在识别: {abs_path}")
    print(f"文件大小: {os.path.getsize(abs_path) / 1024:.2f} KB")
    
    messages = [
        {"role": "system", "content": [{"text": ""}]},
        {"role": "user", "content": [{"audio": audio_file_path}]}
    ]
    
    asr_options = {
        "enable_itn": False
    }
    if language:
        asr_options["language"] = language
        print(f"指定语言: {language}")
    
    response = dashscope.MultiModalConversation.call(
        api_key=API_KEY,
        model="qwen3-asr-flash",  # 若使用美国地域，改为 "qwen3-asr-flash-us"
        messages=messages,
        result_format="message",
        asr_options=asr_options
    )
    
    if response.status_code == 200:
        # 提取识别结果
        output = response.output
        if output and 'choices' in output and len(output['choices']) > 0:
            message = output['choices'][0].get('message', {})
            content = message.get('content', [])
            if content and len(content) > 0:
                return content[0].get('text', '')
        return "未能提取识别结果"
    else:
        print(f"请求失败: {response.status_code}")
        print(f"错误信息: {response.message}")
        return None


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='阿里云 DashScope 语音识别 (本地文件版)')
    parser.add_argument('audio_file', help='音频文件路径 (支持 mp3, wav, m4a, ogg 等)')
    parser.add_argument('-l', '--language', help='语言代码 (如 zh, en)', default=None)
    
    args = parser.parse_args()
    
    print("="*50)
    print("Voice Message 语音识别")
    print("="*50)
    
    result = recognize_audio(args.audio_file, language=args.language)
    
    if result:
        print("\n" + "="*50)
        print("识别结果:")
        print("="*50)
        print(result)
        print("="*50)


if __name__ == '__main__':
    main()
