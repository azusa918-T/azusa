"""
Lark Doc Search Skill
飞书开放平台开发者文档搜索
"""

from .lark_doc_search import search_docs, simple_search

__all__ = ['search_docs', 'simple_search']
